<?php
include 'functions.php';
$id = $_GET['id'];

view($id);
?>