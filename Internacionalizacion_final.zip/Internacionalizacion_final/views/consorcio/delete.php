<?php

require_once 'functions.php';


$id = $_GET['id'];

delete($id);



?>