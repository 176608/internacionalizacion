<?php
echo "Estoy en evento.php";
include('../../_assets/conn.php');
echo '';
//$vista_actual = 3;
//echo $vista_actual;