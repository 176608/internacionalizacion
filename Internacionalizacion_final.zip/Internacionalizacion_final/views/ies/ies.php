<?php
echo "Estoy en ies.php";