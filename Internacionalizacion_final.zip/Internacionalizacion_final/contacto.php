<!DOCTYPE html>
<html lang="en">
<?php include_once 'static/head.php' ?>

<body>

    <?php include_once 'static/navbar.php' ?>

    <div class="jumbotron text-light" style="background-image: url(img/banner.jpg);background-attachment: fixed;background-size: cover;background-position: bottom;">
        <div class="container text-center">
            <h1>SOBRE NOSOTROS</h1>
        </div>
    </div>

    <div class="container-fluid bg-3 text-center" style="padding:0 10% 0 10%">
        <div class="row">

            <div class="col-lg-12">
                <h3 style="font-weight:bold">Correo</h3>
                <p> al666666@alumnos.uacj.mx </p>
                <br><br>
                <h3 style="font-weight:bold">Teléfono</h3>
                <p> 666-666-6666 </p>
                <br><br><br><br><br><br>

            </div>

        </div>
    </div><br><br>

    <?php include_once 'static/footer.php' ?>

</body>

</html>