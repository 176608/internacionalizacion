<?php
function db()
{
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "proyecto";

  // Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);
  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  return $conn;
}

function select_all()
{

  $conn = db();

  $sql = "SELECT * FROM pais";
  $result = $conn->query($sql);
  echo '<table class="rwd-table">';
  echo "<tr>";
  echo  "<th>ID</th>";
  echo  "<th>Pais</th>";
  echo "</tr>";
  if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {

      echo "<tr>";
      echo "<td>" . $row["id_pais"] . "</td>";
      echo "<td>" . $row["Pais"] . "</td>";
      echo '<td> <a href="view.php?id=' . $row["id_pais"] . '">Ver</a></td>';
      echo '<td> <a href="functions/edit.php?id=' . $row["id_pais"] . '">Editar</a></td>';
      echo '<td> <a href="functions/delete.php?id=' . $row["id_pais"] . '">Borrar</a></td>';
      echo "</tr>";
    }
  } else {
    echo "0 results";
  }
}


function view($id)
{

  $conn = db();

  $sql = "SELECT * FROM pais WHERE id_pais = {$id}";
  $result = $conn->query($sql);
  echo "<table>";
  if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {

      echo "<tr>";
      echo "<td>" . $row["id_pais"] . "</td>";
      echo "<td>" . $row["Pais"] . "</td>";
      echo "</tr>";
    }
  } else {
    echo "0 results";
  }
}


function insert($id, $pais)
{
  $conn = db();
  $pais = mysqli_real_escape_string($conn, $pais);
  // Insert data into the database
  $sql = "INSERT INTO pais (Pais) VALUES ('$pais')";

  if ($conn->query($sql) === TRUE) {
    echo "<div class='text-success'><h5>Registro creado exitosamente.</h5></div>";
  } else {
    echo "<div class='text-danger'><h5>Error "  . $sql . "<br>" . $conn->error . ".</h5></div>";
  }
}


function edit($id)
{

  $conn = db();

  $sql = "SELECT * FROM pais WHERE id_pais = {$id}";
  $result = $conn->query($sql);
  echo "<table>";
  if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {
      echo '
      
                <div class="form-group">
                    <label for="inputText1">Pais</label>
                    <input type="text" name="pais" class="form-control" id="inputText1" aria-describedby="textHelp" placeholder=" " value="' . $row['Nombre'] . '">
                </div>

                <button type="submit" name="submit" value="Actualizar" class=" btn btn-dark">Actualizar</button>
            
        ';
    }
  } else {
    echo "0 results";
  }
}

function update($id, $pais)
{
  $conn = db();
  $pais = mysqli_real_escape_string($conn, $pais);
  $sql = "UPDATE pais SET Nombre = '$pais' WHERE id_pais = {$id}";

  if ($conn->query($sql) === TRUE) {
    echo "<div class='text-success'><h5>Registro actualizado exitosamente.</h5></div>";
  } else {
    echo "<div class='text-danger'><h5>Error "  . $sql . "<br>" . $conn->error . ".</h5></div>";
  }
}


function delete($id)
{
  $conn = db();

  $sql = "DELETE FROM ies WHERE id_pais = {$id}";

  if ($conn->query($sql) === TRUE) {
    echo "<div class='text-success'><h5>Registro borrado exitosamente.</h5></div>";
  } else {
    echo "<div class='text-danger'><h5>Error "  . $sql . "<br>" . $conn->error . ".</h5></div>";
  }
}
