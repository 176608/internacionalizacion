<!DOCTYPE html>
<html lang="en">
<?php
include_once '../static/head.php';
include 'functions/functions.php';
?>

<body>
    <?php include_once '../static/navbar.php'; ?>
    
    <div class="container-fluid bg-3 text-center" style="padding:2% 10% 10% 10%">
    <h1>Paises</h1><br>
        <div class="row">
            
            <div class="text-center mx-auto" style="width: 80%;">
               
                <a href="functions/insert.php"><button class="button" role="button">Agregar registro</button></a>
                <a href="../index.php"><button class="button" role="button">Regresar</button></a>
                <div id="tabla">
                    <?php echo select_all(); ?>
                </div>
            </div><br><br>
            
        </div>
    </div>

</body>

</html>