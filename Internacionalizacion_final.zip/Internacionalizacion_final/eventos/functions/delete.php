<!DOCTYPE html>
<html lang="en">
<?php
include_once '../../static/head.php';
include_once 'functions.php';
$id = $_GET['id'];
?>

<body>

    <?php include_once '../../static/navbar.php' ?>

    <div class="container-fluid bg-3 text-center" style="padding:2% 10% 0 10%">
       <br>
        <div class="row">
            <form class="mx-auto" form action="" method="post">

                <?php delete($id); ?>

            </form>
        </div> <br><br>
        <a href="../crud.php"><button class="btn btn-dark" role="button">Ok</button></a>

    </div><br><br>

    <?php include_once '../../static/footer.php' ?>

</body>

</html>