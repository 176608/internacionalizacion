<?php
function db()
{
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "proyecto";

  // Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);
  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  return $conn;
}

function select_all()
{

  $conn = db();

  $sql = "SELECT * FROM evento";
  $result = $conn->query($sql);
  echo '<table class="rwd-table">';
  echo "<tr>";
  echo  "<th>ID - Nombre</th>";
  echo  "<th>Fecha de Inicio</th>";
  echo  "<th>Fecha de Fin</th>";
  echo  "<th>Horarios</th>";
  echo  "<th>Comentarios</th>";
  echo  "<th></th>";
  echo  "<th></th>";
  echo  "<th></th>";
  echo "</tr>";
  if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {

      echo "<tr>";
      echo "<td>" . $row["id_evento"] . " - " . $row["Nombre"] . "</td>";
      echo "<td>" . $row["fecha_inicio"] . "</td>";
      echo "<td>" . $row["fecha_fin"] . "</td>";
      echo "<td>" . $row["Horarios"] . "</td>";
      echo "<td>" . $row["Comentarios"] . "</td>";
      echo '<td> <a href="view.php?id=' . $row["id_evento"] . '">Ver</a></td>';
      echo '<td> <a href="functions/edit.php?id=' . $row["id_evento"] . '">Editar</a></td>';
      echo '<td> <a href="functions/delete.php?id=' . $row["id_evento"] . '">Borrar</a></td>';
      echo "</tr>";
    }
  } else {
    echo "0 results";
  }
}


function view($id)
{

  $conn = db();

  $sql = "SELECT * FROM evento WHERE id_evento = {$id}";
  $result = $conn->query($sql);
  echo "<table>";
  if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {

      echo "<tr>";
      echo "<td>" . $row["id_evento"] . " - " . $row["Nombre"] . "</td>";
      echo "<td>" . $row["fecha_inicio"] . "</td>";
      echo "<td>" . $row["fecha_fin"] . "</td>";
      echo "<td>" . $row["Horarios"] . "</td>";
      echo "<td>" . $row["Comentarios"] . "</td>";
      echo "</tr>";
    }
  } else {
    echo "0 results";
  }
}


function insert($nombre, $fecha_inicio, $fecha_fin, $horarios, $comentarios)
{
  $conn = db();
  $nombre = mysqli_real_escape_string($conn, $nombre);
  $fecha_inicio = mysqli_real_escape_string($conn, $fecha_inicio);
  $fecha_fin = mysqli_real_escape_string($conn, $fecha_fin);
  $horarios = mysqli_real_escape_string($conn, $horarios);
  $comentarios = mysqli_real_escape_string($conn, $comentarios);
  // Insert data into the database
  $sql = "INSERT INTO evento (Nombre, fecha_inicio, fecha_fin, Horarios, Comentarios) VALUES ('$nombre', '$fecha_inicio', '$fecha_fin', '$horarios', '$comentarios')";

  if ($conn->query($sql) === TRUE) {
    echo "<div class='text-success'><h5>Registro creado exitosamente.</h5></div>";
  } else {
    echo "<div class='text-danger'><h5>Error "  . $sql . "<br>" . $conn->error . ".</h5></div>";
  }
}


function edit($id)
{

  $conn = db();

  $sql = "SELECT * FROM evento WHERE id_evento = {$id}";
  $result = $conn->query($sql);
  echo "<table>";
  if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {
      echo '
      
                <div class="form-group">
                    <label for="inputText1">Nombre</label>
                    <input type="text" name="nombre" class="form-control" id="inputText1" aria-describedby="textHelp" placeholder=" " value="' . $row['Nombre'] . '">
                </div>
                <div class="form-group">
                    <label for="inputText2">Fecha de Inicio</label>
                    <input type="text" name="fecha_inicio" class="form-control" id="inputText2" aria-describedby="textHelp" placeholder=" " value="' . $row['fecha_inicio'] . '">
                </div>
                <div class="form-group">
                    <label for="inputText4">Fecha de Fin</label>
                    <input type="text" name="fecha_fin" class="form-control" id="inputText4" aria-describedby="textHelp" placeholder=" " value="' . $row['fecha_fin'] . '">
                </div>
                <div class="form-group">
                    <label for="inputText3">Horarios</label>
                    <input type="text" name="horarios" class="form-control" id="inputText3" aria-describedby="textHelp" placeholder=" " value="' . $row['Horarios'] . '">
                </div>
                <div class="form-group">
                    <label for="inputText3">Comentarios</label>
                    <input type="text" name="comentarios" class="form-control" id="inputText3" aria-describedby="textHelp" placeholder=" " value="' . $row['Comentarios'] . '">
                </div>

                <button type="submit" name="submit" value="Actualizar" class=" btn btn-dark">Actualizar</button>
            
        ';
    }
  } else {
    echo "0 results";
  }
}

function update($id, $nombre, $fecha_inicio, $fecha_fin, $horarios, $comentarios)
{
  $conn = db();
  $nombre = mysqli_real_escape_string($conn, $nombre);
  $fecha_inicio = mysqli_real_escape_string($conn, $fecha_inicio);
  $fecha_fin = mysqli_real_escape_string($conn, $fecha_fin);
  $horarios = mysqli_real_escape_string($conn, $horarios);
  $comentarios = mysqli_real_escape_string($conn, $comentarios);
  // Insert data into the database
  $sql = "UPDATE evento SET Nombre = '$nombre', fecha_inicio = '$fecha_inicio', fecha_fin = '$fecha_fin', Horarios ='$horarios', Comentarios = '$comentarios' WHERE id_evento = {$id}";

  if ($conn->query($sql) === TRUE) {
    echo "<div class='text-success'><h5>Registro actualizado exitosamente.</h5></div>";
  } else {
    echo "<div class='text-danger'><h5>Error "  . $sql . "<br>" . $conn->error . ".</h5></div>";
  }
}


function delete($id)
{
  $conn = db();

  $sql = "DELETE FROM evento WHERE id_evento = {$id}";

  if ($conn->query($sql) === TRUE) {
    echo "<div class='text-success'><h5>Registro borrado exitosamente.</h5></div>";
  } else {
    echo "<div class='text-danger'><h5>Error "  . $sql . "<br>" . $conn->error . ".</h5></div>";
  }
}
