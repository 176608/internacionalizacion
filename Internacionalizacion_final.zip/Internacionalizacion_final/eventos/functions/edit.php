<!DOCTYPE html>
<html lang="en">
<?php
include_once '../../static/head.php';
include_once 'functions.php';
$id = $_GET['id'];
?>

<body>

    <?php include_once '../../static/navbar.php' ?>

    <div class="container-fluid bg-3 text-center" style="padding:2% 10% 0 10%">
        <h4>Inserte los datos a actualizar:</h4><br>
        <div class="row">
            <form class="mx-auto" form action="" method="post">

                <?php

                edit($id);

                ?>

            </form>


        </div> <br><br>

        <?php
        // Verifica si el formulario se ha enviado
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Procesar los datos del formulario

            // Aquí puedes acceder a los datos del formulario usando $_POST
            $nombre = $_POST['nombre'];
            $fecha_inicio = $_POST['fecha_inicio'];
            $fecha_fin = $_POST['fecha_fin'];
            $horarios = $_POST['horarios'];
            $comentarios = $_POST['comentarios'];

            update($id, $nombre, $fecha_inicio, $fecha_fin, $horarios, $comentarios);
        }
        ?>
        <br><br>
        <a href="../crud.php"><button class="btn btn-dark" role="button">Regresar</button></a>

    </div><br><br>

    <?php include_once '../../static/footer.php' ?>

</body>

</html>