<!DOCTYPE html>
<html lang="en" style="position: relative; min-height: 100%;">
<?php
include_once '../static/head.php';
include('../conn.php');
?>

<body>

    <?php include_once '../static/navbar.php' ?>

    <div class="container-fluid bg-3 text-center" style="padding:2% 10% 0 10%">
        <h3>Lista de Eventos</h3><br>
        <div class="row">

            <!-- Tabla de eventos -->
            <div class="container-fluid">

                <a href="crud.php"><button class="button" role="button">Editar Tabla</button></a>
                <a href="../index.php"><button class="button" role="button">Regresar</button></a><br><br>

                <?php
                $query = "SELECT id_evento, Nombre, fecha_inicio, fecha_fin, Horarios, Comentarios FROM evento";
                $resultado = mysqli_query($conn, $query);
                if ($resultado) {
                    // Iniciar la tabla HTML
                    echo '
                <table class="table" id="test" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th scope="col">#ID</th>
                            <th scope="col">Nombre</th>
                            <th scope="col">Fecha de Inicio</th>
                            <th scope="col">Fecha de Fin</th>
                            <th scope="col">Horarios</th>
                            <th scope="col">Comentarios</th>
                        </tr>
                    </thead>
                    <tbody>
                    ';
                // Iterar sobre los resultados
                while ($fila = mysqli_fetch_assoc($resultado)) {
                    echo '
                    <tr>
                        <td>' . $fila['id_evento'] . '</td>
                        <td>' . $fila['Nombre'] . '</td>
                        <td>' . $fila['fecha_inicio'] . '</td>
                        <td>' . $fila['fecha_fin'] . '</td>
                        <td>' . $fila['Horarios'] . '</td>
                        <td>' . $fila['Comentarios'] . '</td>
                    </tr>';
                }
                // Cerrar la tabla HTML
                echo '
                    </tbody>
                </table>
                ';
                } else {
                    // Manejar el caso en que la consulta no fue exitosa
                    echo 'Error en la consulta: ' . mysqli_error($conn);
                }

                // Cerrar la conexión a la base de datos
                mysqli_close($conn);
                ?>

            </div>

        </div>
    </div><br><br>

    <script>
        new DataTable('#test');
    </script>

</body>

</html>