<!DOCTYPE html>
<html lang="en">
<?php include_once 'static/head.php' ?>

<body>

    <?php include_once 'static/navbar.php' ?>

    <div class="jumbotron text-light" style="background-image: url(img/banner.jpg);background-attachment: fixed;background-size: cover;background-position: bottom;">
        <div class="container text-center">
            <h1>SOBRE NOSOTROS</h1>
        </div>
    </div>

    <div class="container-fluid bg-3 text-center" style="padding:0 10% 0 10%">
        <div class="row">

            <div class="col-lg-12">
                <h3 style="font-weight:bold">Misión</h3>
                <p>El propósito de la base de datos es almacenar datos para mantener la información de IES (Instituciones de Educación Superior) centralizada y organizada. </p>
                <br><br>
                <h3 style="font-weight:bold">Objetivos</h3>
                <p>
                    • Almacenar la información actualizada del personal académico de IES a nivel nacional e internacional.<br>
                    • Almacenar la relación entre las universidades y los consorcios a los que pertenecen.<br>
                    • Mantener la información de las IES y personal de internacionalización que participan en distintos eventos de los que nuestra institución forma parte.<br>
                    • Mantener datos para la centralización y modularidad de toda la información descrita para su fácil interrelación.
                </p><br><br>
                <h3 style="font-weight:bold">Enunciado del problema</h3>
                <p>
                    La universidad autónoma de Ciudad Juárez está interesada en guardar la información de las instituciones de educación superior (IES) nacionales e internacionales y conforme pase el tiempo se añadirán más o se actualizara la información.<br><br>
                    Cada IES tiene personal académico que se caracteriza por su nombre, departamento, cargo, teléfono celular y correos. Al igual que cada IES tiene diferentes campus las cuales se ubican en diferentes partes de la ciudad o del estado y cuentan con un nombre propio.<br><br>
                    Es posible que cada IES este afiliado a uno o varios consorcios, es necesario tener el nombre, siglas, sitio web oficial, si es una asociación, consorcio o centro de investigación, su procedencia y el instrumento que utilizan, si membresía, convenio o adhesión.<br><br>
                    Cada IES puede organizar o participar en diferentes eventos, los cuales tendrán una fecha de inicio y una fecha de termino, nombre de dicho evento y sus comentarios acerca del evento.<br><br>
                    En ocasiones en los consorcios tiene un encargado, los cuales suelen ser personal académico de las universidades, al igual esto pueden ser los organizadores principales o quienes van como representante de dicha universidad.

                </p><br><br>

            </div>

        </div>
    </div><br><br>

    <?php include_once 'static/footer.php' ?>

</body>

</html>