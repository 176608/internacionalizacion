<?php
function db()
{
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "proyecto";

  // Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);
  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  return $conn;
}

function select_all()
{

  $conn = db();

  $sql = "SELECT * FROM ies";
  $result = $conn->query($sql);
  echo '<table class="rwd-table">';
  echo "<tr>";
  echo  "<th>ID - Nombre</th>";
  echo  "<th>Siglas</th>";
  echo  "<th>Página Web</th>";
  echo  "<th>ID País</th>";
  echo  "<th></th>";
  echo  "<th></th>";
  echo  "<th></th>";
  echo "</tr>";
  if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {

      echo "<tr>";
      echo "<td>" . $row["id_IES"] . " - " . $row["Nombre"] . "</td>";
      echo "<td>" . $row["Siglas"] . "</td>";
      echo "<td>" . $row["PaginaWeb"] . "</td>";
      echo "<td>" . $row["id_pais"] . "</td>";
      echo '<td> <a href="view.php?id=' . $row["id_IES"] . '">Ver</a></td>';
      echo '<td> <a href="functions/edit.php?id=' . $row["id_IES"] . '">Editar</a></td>';
      echo '<td> <a href="functions/delete.php?id=' . $row["id_IES"] . '">Borrar</a></td>';
      echo "</tr>";
    }
  } else {
    echo "0 results";
  }
}


function view($id)
{

  $conn = db();

  $sql = "SELECT * FROM ies WHERE id_IES = {$id}";
  $result = $conn->query($sql);
  echo "<table>";
  if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {

      echo "<tr>";
      echo "<td>" . $row["id_IES"] . " - " . $row["Nombre"] . "</td>";
      echo "<td>" . $row["Siglas"] . "</td>";
      echo "<td>" . $row["PPaginaWeb"] . "</td>";
      echo "<td>" . $row["id_pais"] . "</td>";
      echo "</tr>";
    }
  } else {
    echo "0 results";
  }
}


function insert($nombre, $siglas, $pagina, $id_pais)
{
  $conn = db();
  $nombre = mysqli_real_escape_string($conn, $nombre);
  $siglas = mysqli_real_escape_string($conn, $siglas);
  $pagina = mysqli_real_escape_string($conn, $pagina);
  $id_pais = mysqli_real_escape_string($conn, $id_pais);
  // Insert data into the database
  $sql = "INSERT INTO ies (Nombre, Siglas, PaginaWeb, id_pais) VALUES ('$nombre', '$siglas', '$pagina', '$id_pais')";

  if ($conn->query($sql) === TRUE) {
    echo "<div class='text-success'><h5>Registro creado exitosamente.</h5></div>";
  } else {
    echo "<div class='text-danger'><h5>Error "  . $sql . "<br>" . $conn->error . ".</h5></div>";
  }
}


function edit($id)
{

  $conn = db();

  $sql = "SELECT * FROM ies WHERE id_IES = {$id}";
  $result = $conn->query($sql);
  echo "<table>";
  if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {
      echo '
      
                <div class="form-group">
                    <label for="inputText1">Nombre</label>
                    <input type="text" name="nombre" class="form-control" id="inputText1" aria-describedby="textHelp" placeholder=" " value="' . $row['Nombre'] . '">
                </div>
                <div class="form-group">
                    <label for="inputText2">Siglas</label>
                    <input type="text" name="siglas" class="form-control" id="inputText2" aria-describedby="textHelp" placeholder=" " value="' . $row['Siglas'] . '">
                </div>
                <div class="form-group">
                    <label for="inputText4">Pagina Web</label>
                    <input type="text" name="pagina" class="form-control" id="inputText4" aria-describedby="textHelp" placeholder=" " value="' . $row['PaginaWeb'] . '">
                </div>
                <div class="form-group">
                    <label for="inputText3">ID Pais</label>
                    <input type="text" name="id_pais" class="form-control" id="inputText3" aria-describedby="textHelp" placeholder=" " value="' . $row['id_pais'] . '">
                </div>

                <button type="submit" name="submit" value="Actualizar" class=" btn btn-dark">Actualizar</button>
            
        ';
    }
  } else {
    echo "0 results";
  }
}

function update($id, $nombre, $siglas, $pagina, $id_pais)
{
  $conn = db();
  $nombre = mysqli_real_escape_string($conn, $nombre);
  $siglas = mysqli_real_escape_string($conn, $siglas);
  $pagina = mysqli_real_escape_string($conn, $pagina);
  $id_pais = mysqli_real_escape_string($conn, $id_pais);  // Insert data into the database
  $sql = "UPDATE ies SET Nombre = '$nombre', Siglas = '$siglas', PaginaWeb = '$pagina', id_pais ='$id_pais' WHERE id_IES = {$id}";

  if ($conn->query($sql) === TRUE) {
    echo "<div class='text-success'><h5>Registro actualizado exitosamente.</h5></div>";
  } else {
    echo "<div class='text-danger'><h5>Error "  . $sql . "<br>" . $conn->error . ".</h5></div>";
  }
}


function delete($id)
{
  $conn = db();

  $sql = "DELETE FROM ies WHERE id_IES = {$id}";

  if ($conn->query($sql) === TRUE) {
    echo "<div class='text-success'><h5>Registro borrado exitosamente.</h5></div>";
  } else {
    echo "<div class='text-danger'><h5>Error "  . $sql . "<br>" . $conn->error . ".</h5></div>";
  }
}
