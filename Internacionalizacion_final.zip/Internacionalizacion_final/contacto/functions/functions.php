<?php
function db()
{
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "proyecto";

  // Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);
  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  return $conn;
}

function select_all()
{

  $conn = db();

  $sql = "SELECT * FROM contacto";
  $result = $conn->query($sql);
  echo '<table class="rwd-table">';
  echo "<tr>";
  echo  "<th>ID - Nombre</th>";
  echo  "<th>Cargo</th>";
  echo  "<th>Telefono</th>";
  echo  "<th>Celular</th>";
  echo  "<th></th>";
  echo  "<th></th>";
  echo  "<th></th>";
  echo "</tr>";
  if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {

      echo "<tr>";
      echo "<td>" . $row["id_contacto"] . " - " . $row["Nombre"] . "</td>";
      echo "<td>" . $row["Cargo"] . "</td>";
      echo "<td>" . $row["Telefono"] . "</td>";
      echo "<td>" . $row["NumeroCelular"] . "</td>";
      echo '<td> <a href="view.php?id=' . $row["id_contacto"] . '">Ver</a></td>';
      echo '<td> <a href="functions/edit.php?id=' . $row["id_contacto"] . '">Editar</a></td>';
      echo '<td> <a href="functions/delete.php?id=' . $row["id_contacto"] . '">Borrar</a></td>';
      echo "</tr>";
    }
  } else {
    echo "0 results";
  }
}


function view($id)
{

  $conn = db();

  $sql = "SELECT * FROM contacto WHERE id_contacto = {$id}";
  $result = $conn->query($sql);
  echo "<table>";
  if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {

      echo "<tr>";
      echo "<td>" . $row["id_contacto"] . " - " . $row["Nombre"] . "</td>";
      echo "<td>" . $row["Cargo"] . "</td>";
      echo "<td>" . $row["Telefono"] . "</td>";
      echo "<td>" . $row["NumeroCelular"] . "</td>";
      echo "</tr>";
    }
  } else {
    echo "0 results";
  }
}


function insert($nombre, $cargo, $telefono, $celular)
{
  $conn = db();
  $nombre = mysqli_real_escape_string($conn, $nombre);
  $cargo = mysqli_real_escape_string($conn, $cargo);
  $telefono = mysqli_real_escape_string($conn, $telefono);
  $celular = mysqli_real_escape_string($conn, $celular);
  // Insert data into the database
  $sql = "INSERT INTO contacto (Nombre, Cargo, Telefono, NumeroCelular) VALUES ('$nombre', '$cargo', '$telefono', '$celular')";

  if ($conn->query($sql) === TRUE) {
    echo "<div class='text-success'><h5>Registro creado exitosamente.</h5></div>";
  } else {
    echo "<div class='text-danger'><h5>Error "  . $sql . "<br>" . $conn->error . ".</h5></div>";
  }
}


function edit($id)
{

  $conn = db();

  $sql = "SELECT * FROM contacto WHERE id_contacto = {$id}";
  $result = $conn->query($sql);
  echo "<table>";
  if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {
      echo '
      
                <div class="form-group">
                    <label for="inputText1">Nombre</label>
                    <input type="text" name="nombre" class="form-control" id="inputText1" aria-describedby="textHelp" placeholder=" " value="' . $row['Nombre'] . '">
                </div>
                <div class="form-group">
                    <label for="inputText2">Cargo</label>
                    <input type="text" name="cargo" class="form-control" id="inputText2" aria-describedby="textHelp" placeholder=" " value="' . $row['Cargo'] . '">
                </div>
                <div class="form-group">
                    <label for="inputText4">Telefono</label>
                    <input type="text" name="telefono" class="form-control" id="inputText4" aria-describedby="textHelp" placeholder=" " value="' . $row['Telefono'] . '">
                </div>
                <div class="form-group">
                    <label for="inputText3">Celular</label>
                    <input type="text" name="celular" class="form-control" id="inputText3" aria-describedby="textHelp" placeholder=" " value="' . $row['NumeroCelular'] . '">
                </div>

                <button type="submit" name="submit" value="Actualizar" class=" btn btn-dark">Actualizar</button>
            
        ';
    }
  } else {
    echo "0 results";
  }
}

function update($id, $nombre, $cargo, $telefono, $celular)
{
  $conn = db();
  $nombre = mysqli_real_escape_string($conn, $nombre);
  $cargo = mysqli_real_escape_string($conn, $cargo);
  $telefono = mysqli_real_escape_string($conn, $telefono);
  $celular = mysqli_real_escape_string($conn, $celular);
  // Insert data into the database
  $sql = "UPDATE contacto SET Nombre = '$nombre', Cargo = '$cargo', Telefono = '$telefono', NumeroCelular ='$celular' WHERE id_contacto = {$id}";

  if ($conn->query($sql) === TRUE) {
    echo "<div class='text-success'><h5>Registro actualizado exitosamente.</h5></div>";
  } else {
    echo "<div class='text-danger'><h5>Error "  . $sql . "<br>" . $conn->error . ".</h5></div>";
  }
}


function delete($id)
{
  $conn = db();

  $sql = "DELETE FROM contacto WHERE id_contacto = {$id}";

  if ($conn->query($sql) === TRUE) {
    echo "<div class='text-success'><h5>Registro borrado exitosamente.</h5></div>";
  } else {
    echo "<div class='text-danger'><h5>Error "  . $sql . "<br>" . $conn->error . ".</h5></div>";
  }
}
