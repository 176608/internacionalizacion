<!DOCTYPE html>
<html lang="en">
<?php include_once '../../static/head.php' ?>

<body>

    <?php include_once '../../static/navbar.php' ?>

    <div class="container-fluid bg-3 text-center" style="padding:2% 10% 10% 10%">
        <h4>Inserte los datos a registrar en la tabla de consorcios:</h4><br>
        <div class="row">

            <form class="mx-auto" form action="" method="post">
                <div class="form-group">
                    <label for="inputText1">Siglas</label>
                    <input type="text" name="siglas" class="form-control" id="inputText1" aria-describedby="textHelp" placeholder=" ">
                </div>
                <div class="form-group">
                    <label for="inputText2">Nombre</label>
                    <input type="text" name="nombre" class="form-control" id="inputText2" aria-describedby="textHelp" placeholder=" ">
                </div>
                <div class="form-group">
                    <label for="inputText3">Enlace</label>
                    <input type="text" name="enlace" class="form-control" id="inputText3" aria-describedby="textHelp" placeholder=" ">
                </div>

                <button type="submit" name="submit" value="Subir" class=" btn btn-dark">Subir</button>
            </form>

        </div> <br><br>

        <?php

        include_once 'functions.php';
        // Verifica si el formulario se ha enviado
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Procesar los datos del formulario

            // Aquí puedes acceder a los datos del formulario usando $_POST
            $siglas = $_POST['siglas'];
            $nombre = $_POST['nombre'];
            $enlace = $_POST['enlace'];

            insert($siglas, $nombre, $enlace);
        }
        ?>
        <br><br>
        <a href="../crud.php"><button class="btn btn-dark" role="button">Regresar</button></a>

    </div><br><br>

    <?php include_once '../../static/footer.php' ?>

</body>

</html>