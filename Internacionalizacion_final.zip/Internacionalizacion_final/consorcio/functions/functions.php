<?php
function db()
{
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "proyecto";

  // Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);
  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  return $conn;
}

function select_all()
{

  $conn = db();

  $sql = "SELECT * FROM consorcio";
  $result = $conn->query($sql);
  echo '<table class="rwd-table">';
  echo "<tr>";
  echo  "<th>ID - Siglas</th>";
  echo  "<th>Nombre</th>";
  echo  "<th>Enlace</th>";
  echo  "<th></th>";
  echo  "<th></th>";
  echo  "<th></th>";
  echo "</tr>";
  if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {

      echo "<tr>";
      echo "<td>" . $row["id_consorcio"] . " - " . $row["Siglas"] . "</td>";
      echo "<td>" . $row["Nombre"] . "</td>";
      echo "<td>" . $row["Enlace"] . "</td>";
      echo '<td> <a href="view.php?id=' . $row["id_consorcio"] . '">Ver</a></td>';
      echo '<td> <a href="functions/edit.php?id=' . $row["id_consorcio"] . '">Editar</a></td>';
      echo '<td> <a href="functions/delete.php?id=' . $row["id_consorcio"] . '">Borrar</a></td>';
      echo "</tr>";
    }
  } else {
    echo "0 results";
  }
}


function view($id)
{

  $conn = db();

  $sql = "SELECT * FROM consorcio WHERE id_consorcio = {$id}";
  $result = $conn->query($sql);
  echo "<table>";
  if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {

      echo "<tr>";
      echo "<td>" . $row["id_consorcio"] . " - " . $row["Siglas"] . "</td>";
      echo "<td>" . $row["Nombre"] . "</td>";
      echo "<td>" . $row["Enlace"] . "</td>";
      echo "</tr>";
    }
  } else {
    echo "0 results";
  }
}


function insert($siglas, $nombre, $enlace)
{
  $conn = db();
  $siglas = mysqli_real_escape_string($conn, $siglas);
  $nombre = mysqli_real_escape_string($conn, $nombre);
  $enlace = mysqli_real_escape_string($conn, $enlace);
  // Insert data into the database
  $sql = "INSERT INTO consorcio (Nombre, Enlace, Siglas) VALUES ('$nombre', '$enlace', '$siglas')";

  if ($conn->query($sql) === TRUE) {
    echo "<div class='text-success'><h5>Registro creado exitosamente.</h5></div>";
  } else {
    echo "<div class='text-danger'><h5>Error "  . $sql . "<br>" . $conn->error . ".</h5></div>";
  }
}


function edit($id)
{

  $conn = db();

  $sql = "SELECT * FROM consorcio WHERE id_consorcio = {$id}";
  $result = $conn->query($sql);
  echo "<table>";
  if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {
      echo '
      
                <div class="form-group">
                    <label for="inputText1">Siglas</label>
                    <input type="text" name="siglas" class="form-control" id="inputText1" aria-describedby="textHelp" placeholder=" " value="' . $row['Siglas'] . '">
                </div>
                <div class="form-group">
                    <label for="inputText2">Nombre</label>
                    <input type="text" name="nombre" class="form-control" id="inputText2" aria-describedby="textHelp" placeholder=" " value="' . $row['Nombre'] . '">
                </div>
                <div class="form-group">
                    <label for="inputText3">Enlace</label>
                    <input type="text" name="enlace" class="form-control" id="inputText3" aria-describedby="textHelp" placeholder=" " value="' . $row['Enlace'] . '">
                </div>

                <button type="submit" name="submit" value="Actualizar" class=" btn btn-dark">Actualizar</button>
            
        ';
    }
  } else {
    echo "0 results";
  }
}

function update($id, $siglas, $nombre, $enlace)
{
  $conn = db();
  $siglas = mysqli_real_escape_string($conn, $siglas);
  $nombre = mysqli_real_escape_string($conn, $nombre);
  $enlace = mysqli_real_escape_string($conn, $enlace);
  // Insert data into the database
  $sql = "UPDATE consorcio SET Siglas = '$siglas', Nombre = '$nombre', Enlace = '$enlace' WHERE id_consorcio = {$id}";

  if ($conn->query($sql) === TRUE) {
    echo "<div class='text-success'><h5>Registro actualizado exitosamente.</h5></div>";
  } else {
    echo "<div class='text-danger'><h5>Error "  . $sql . "<br>" . $conn->error . ".</h5></div>";
  }
}


function delete($id)
{
  $conn = db();

  $sql = "DELETE FROM consorcio WHERE id_consorcio = {$id}";

  if ($conn->query($sql) === TRUE) {
    echo "<div class='text-success'><h5>Registro borrado exitosamente.</h5></div>";
  } else {
    echo "<div class='text-danger'><h5>Error "  . $sql . "<br>" . $conn->error . ".</h5></div>";
  }
}
