<!DOCTYPE html>
<html lang="en" style="position: relative; min-height: 100%;">
<?php
include_once '../static/head.php';
include('../conn.php');
?>

<body>

    <?php include_once '../static/navbar.php' ?>

    <div class="container-fluid bg-3 text-center" style="padding:2% 10% 0 10%">
        <h3>Lista de Consorcios</h3><br>
        <div class="row">

            <!-- Tabla de consorcio -->
            <div class="container-fluid">

                <a href="crud.php"><button class="button" role="button">Editar Tabla</button></a>
                <a href="../index.php"><button class="button" role="button">Regresar</button></a><br><br>

                <?php
                $query = "SELECT id_consorcio, Siglas, Nombre, Enlace FROM consorcio";
                $resultado = mysqli_query($conn, $query);
                if ($resultado) {
                    // Iniciar la tabla HTML
                    echo '
                <table class="table" id="test" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th scope="col">#ID</th>
                            <th scope="col">Siglas</th>
                            <th scope="col">Nombre</th>
                            <th scope="col">Enlace</th>
                        </tr>
                    </thead>
                    <tbody>
                    ';
                // Iterar sobre los resultados
                while ($fila = mysqli_fetch_assoc($resultado)) {
                    echo '
                    <tr>
                        <td>' . $fila['id_consorcio'] . '</td>
                        <td>' . $fila['Siglas'] . '</td>
                        <td>' . $fila['Nombre'] . '</td>
                        <td>' . $fila['Enlace'] . '</td>
                    </tr>';
                }
                // Cerrar la tabla HTML
                echo '
                    </tbody>
                </table>
                ';
                } else {
                    // Manejar el caso en que la consulta no fue exitosa
                    echo 'Error en la consulta: ' . mysqli_error($conn);
                }

                // Cerrar la conexión a la base de datos
                mysqli_close($conn);
                ?>

            </div>

        </div>
    </div><br><br>

    <script>
        new DataTable('#test');
    </script>

</body>

</html>