<!DOCTYPE html>
<html lang="en">

<?php
// Iniciar la sesión
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuarios'])) {
    // Si no ha iniciado sesión, redirigir a la página de inicio de sesión
    header("Location: login.html");
    exit();
}
?>

<?php include_once 'static/head.php' ?>

<body>

  <?php include_once 'static/navbar.php' ?>

  <div class="jumbotron text-light" style="background-image: url(img/banner.jpg);background-attachment: fixed;background-size: cover;background-position: bottom;">
    <div class="container text-center">
      <h1>CATÁLOGO</h1>
      <p>Conectando a Estudiantes y Docentes en todo el mundo.</p>
    </div>
  </div>

  <div class="container-fluid bg-3 text-center" style ="padding:0 10% 0 10%">
    <h3>Listas:</h3><br>
    <div class="row">

      <div class="col-lg-6">
        <div class="dropdown">
          <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Consorcios
          </button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a class="dropdown-item" href="consorcio/crud.php">Editar Tabla</a>
            <a class="dropdown-item" href="consorcio/view.php">Ver Tabla</a>
          </div>
        </div>
        <img src="img/hand.jpg" class="img-responsive" style="width:400px; margin:15px 0 15px 0;" alt="Image">
      </div>

      <div class="col-lg-6">
        <div class="dropdown">
          <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Instrumentos, Países, Tipo de Consorcios
          </button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a class="dropdown-item" href="paises/crud.php">Editar Tabla</a>
            <a class="dropdown-item" href="paises/view.php">Ver Tabla</a>
          </div>
        </div>
        <img src="img/passport.jpg" class="img-responsive" style="width:400px; margin:15px 0 15px 0;" alt="Image">
      </div>

      <div class="col-lg-6">
        <div class="dropdown">
          <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Eventos
          </button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a class="dropdown-item" href="eventos/crud.php">Editar Tabla</a>
            <a class="dropdown-item" href="eventos/view.php">Ver Tabla</a>
          </div>
        </div>
        <img src="img/eventos.jpg" class="img-responsive" style="width:400px; margin:15px 0 15px 0;" alt="Image">
      </div>

      <div class="col-lg-6">
        <div class="dropdown">
          <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            IES, Campus y Departamentos
          </button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a class="dropdown-item" href="ies/crud.php">Editar Tabla</a>
            <a class="dropdown-item" href="ies/view.php">Ver Tabla</a>
          </div>
        </div>
        <img src="img/unam.jpg" class="img-responsive" style="width:400px; margin:15px 0 15px 0;" alt="Image">
      </div>

      <div class="col-sm-12">
      <div class="dropdown">
          <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Contactos
          </button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a class="dropdown-item" href="contacto/crud.php">Editar Tabla</a>
            <a class="dropdown-item" href="contacto/view.php">Ver Tabla</a>
          </div>
        </div>
        <img src="img/email.jpg" class="img-responsive" style="width:400px; margin:15px 0 15px 0;" alt="Image">
      </div>

    </div>
  </div><br><br>

  <?php include_once 'static/footer.php' ?>

</body>

</html>